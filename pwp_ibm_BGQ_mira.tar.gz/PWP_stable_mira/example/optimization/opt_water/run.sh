#!/bin/sh
nodes=512
mode=1
nprocs=1

  echo "before staging job:  "  `date`
  runjob -p ${mode} --np ${nprocs} --block ${COBALT_PARTNAME} --verbose=INFO : ./pwpmpi > log.naqmd
  echo "after staging job:   "  `date`
