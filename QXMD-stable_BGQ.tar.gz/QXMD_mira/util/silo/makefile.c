#################################
#   Makefile for MD (Sun WS)    #
#################################
.SUFFIXES:
.SUFFIXES:	.c .o .l

     LINKER        = gcc
     LDFLAGS       = 
     FFLAGS        = -c
#     LINKER        = frt
#     LDFLAGS       = 
#     FFLAGS        = -c -f 2008 -f 2004 -f 2006
#     LINKER        = gfortran
#     LDFLAGS       = 
#     FFLAGS        = -c
#HP#     LINKER        = f77
#HP#     LDFLAGS       = +O3 -K
#HP#     FFLAGS        = -c +O3 -K
#SUN#     LINKER        = f77
#SUN#     LDFLAGS       = -C -fast -O3
#SUN#     FFLAGS        = -c -C -fast -O3
#     LDFLAGS       = -C
#     FFLAGS        = -c -C

MAKEFILE	= Makefile

FC	= $(LINKER)

LIBS= -L/usr/local/silo-4.6.2/lib -lsilo -lm
INCLUDES= -I/usr/local/silo-4.6.2/include


PROGRAM	= silo
OBJS	= \
	 silo.o


.c.o:
		$(FC) $(FFLAGS) $(INCLUDES) $*.c

all:		$(PROGRAMS)

com:		$(OBJS)


$(PROGRAM):	$(OBJS)
		@echo "Loading $(PROGRAM) ... "
		$(LINKER) $(LDFLAGS) $(LIBS) $(OBJS) -o $(PROGRAM)
		\mv $(PROGRAM) ..
		@echo "done"


###############
# maintenance #
###############
clean:
		@rm -f $(OBJS) $(PROGRAMS) $(LISTS)

